# Autonomous Delivery Agent - Python

Run the project:

    python main.py --example

Includes BFS, UCS, A*, and Simulated Annealing local replanning.
See report.md for details.