# Report: Autonomous Delivery Agent (short version)

See project description for methodology, results, and analysis.