from collections import deque
from utils import reconstruct_path

def bfs(grid, start, goal):
    frontier = deque([start])
    came_from = {start: None}
    expanded = 0
    while frontier:
        curr = frontier.popleft()
        expanded += 1
        if curr == goal:
            path = reconstruct_path(came_from, start, goal)
            return path, {'expanded': expanded, 'cost': len(path)-1}
        for n in grid.neighbors(curr):
            if n not in came_from:
                came_from[n] = curr
                frontier.append(n)
    return [], {'expanded': expanded, 'cost': None}
