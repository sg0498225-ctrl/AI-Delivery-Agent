from utils import reconstruct_path

def heuristic(a,b):
    return abs(a[0]-b[0]) + abs(a[1]-b[1])

def hill_climbing(grid, start, goal, max_steps=1000):
    current = start
    came_from = {start: None}
    expanded = 0
    for _ in range(max_steps):
        expanded += 1
        if current == goal:
            return reconstruct_path(came_from, start, goal), {'expanded': expanded, 'cost': len(reconstruct_path(came_from,start,goal))-1}
        neighbors = grid.neighbors(current)
        if not neighbors:
            break
        # choose neighbor with best heuristic (closest to goal)
        best = min(neighbors, key=lambda n: heuristic(n, goal))
        if heuristic(best, goal) >= heuristic(current, goal):
            # no improvement — stuck
            break
        came_from[best] = current
        current = best
    return [], {'expanded': expanded, 'cost': None}
