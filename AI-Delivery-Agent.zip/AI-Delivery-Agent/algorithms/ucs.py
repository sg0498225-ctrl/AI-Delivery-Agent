import heapq
from utils import reconstruct_path

def ucs(grid, start, goal):
    pq = []
    heapq.heappush(pq, (0, start))
    came_from = {start: None}
    cost_so_far = {start: 0}
    expanded = 0
    while pq:
        cost, curr = heapq.heappop(pq)
        expanded += 1
        if curr == goal:
            path = reconstruct_path(came_from, start, goal)
            return path, {'expanded': expanded, 'cost': cost}
        for n in grid.neighbors(curr):
            new_cost = cost_so_far[curr] + grid.cost(curr, n)
            if n not in cost_so_far or new_cost < cost_so_far[n]:
                cost_so_far[n] = new_cost
                heapq.heappush(pq, (new_cost, n))
                came_from[n] = curr
    return [], {'expanded': expanded, 'cost': None}
