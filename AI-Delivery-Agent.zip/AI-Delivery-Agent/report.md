# Short Report (Sample) - AI Delivery Agent

## Environment model
- Grid cells: integer movement cost >= 1
- `1` marks obstacle (impassable). `0` or integers >=1 indicate free cells and movement cost.
- Dynamic obstacles: `D` token in dynamic map indicates moving obstacle (example skeleton).

## Algorithms implemented
- BFS: breadth-first search for shortest number of steps (ignores varying costs).
- UCS: finds lowest cost path with integer movement costs.
- A*: UCS + heuristic (Manhattan) for faster goal-directed search.
- Hill Climbing: greedy local search using heuristic; may get stuck in local optima.

## Experiments (how to run)
- Use `main.py` to run all algorithms on `maps/map_small.txt`.
- Compare output path cost, nodes expanded, and runtime using printed results.

## Conclusion
- A* usually performs best when heuristic is admissible and informative.
- UCS guarantees optimal cost path for varying costs.
- BFS is good for uniform-cost grids (or when cost doesn't matter).
- Hill climbing is fast but not guaranteed to find optimal path and can fail on complex maps.
