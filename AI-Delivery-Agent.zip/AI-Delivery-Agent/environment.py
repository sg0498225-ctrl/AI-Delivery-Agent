import os

class Grid:
    def __init__(self, filename):
        self.filename = filename
        self.grid = []
        self.rows = 0
        self.cols = 0
        self.start = None
        self.goal = None
        self._load(filename)

    def _load(self, filename):
        with open(filename, 'r') as f:
            for r, line in enumerate(f):
                line=line.strip()
                if not line: continue
                parts = line.split()
                row = []
                for c, p in enumerate(parts):
                    if p.upper() == 'S':
                        row.append(1)
                        self.start = (r, c)
                    elif p.upper() == 'G':
                        row.append(1)
                        self.goal = (r, c)
                    elif p.upper() == 'D':
                        # dynamic obstacle placeholder treated as blocked for static runs
                        row.append(float('inf'))
                    else:
                        try:
                            val = int(p)
                            if val == 1:
                                # treat '1' as obstacle marker in example maps
                                row.append(0)  # free cell with cost 1 represented as 0 in sample maps — override below
                                # We'll assume 0 -> free cost 1, >1 -> cost
                                row[-1] = 1 if val == 0 else (val if val>0 else 1)
                            else:
                                row.append(val)
                        except:
                            # default free cell cost 1
                            row.append(1)
                self.grid.append(row)
        self.rows = len(self.grid)
        self.cols = len(self.grid[0]) if self.rows>0 else 0

    def in_bounds(self, pos):
        r,c = pos
        return 0<=r<self.rows and 0<=c<self.cols

    def passable(self, pos):
        r,c = pos
        val = self.grid[r][c]
        # treat very large or 0 as blocked
        if val == 0 or val == float('inf'):
            return False
        return True

    def cost(self, from_node, to_node):
        r,c = to_node
        val = self.grid[r][c]
        # Interpret 0 as free cost 1, other positive ints as costs
        if val == 0:
            return 1
        try:
            return int(val)
        except:
            return 1

    def neighbors(self, pos):
        r,c = pos
        results = [(r-1,c),(r+1,c),(r,c-1),(r,c+1)]
        results = filter(self.in_bounds, results)
        results = filter(self.passable, results)
        return list(results)
