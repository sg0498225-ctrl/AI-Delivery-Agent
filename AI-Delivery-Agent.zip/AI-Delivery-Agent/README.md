# AI-Delivery-Agent

An educational project implementing pathfinding algorithms for an autonomous delivery agent in a 2D grid world.

Includes:
- BFS (uninformed)
- UCS (Uniform Cost Search)
- A* with Manhattan heuristic
- Hill Climbing (local search)
- Environment loader and simple dynamic obstacle support (skeleton)
- Example maps and a main runner

Run the demo:
```bash
python3 main.py
```

Folder structure
```
AI-Delivery-Agent/
├── maps/
├── algorithms/
├── main.py
├── environment.py
├── utils.py
├── README.md
└── report.md
```
