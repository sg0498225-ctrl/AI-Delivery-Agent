from algorithms.bfs import bfs
from algorithms.ucs import ucs
from algorithms.astar import astar
from algorithms.hill_climbing import hill_climbing
from environment import Grid
import time

def run_on_map(mapfile, start=None, goal=None):
    grid = Grid(mapfile)
    if start is None or goal is None:
        start = grid.start
        goal = grid.goal
    print(f"\n=== Running on {mapfile} ===")
    print("Start:", start, "Goal:", goal, "Grid size:", (grid.rows, grid.cols))
    for name, fn in [("BFS", bfs), ("UCS", ucs), ("A*", astar), ("HillClimbing", hill_climbing)]:
        t0 = time.time()
        path, info = fn(grid, start, goal)
        t1 = time.time()
        print(f"{name}: time={t1-t0:.4f}s, nodes_expanded={info.get('expanded', None)}, path_cost={info.get('cost', None)}")
        print(" Path:", path)

if __name__ == '__main__':
    run_on_map('maps/map_small.txt')
